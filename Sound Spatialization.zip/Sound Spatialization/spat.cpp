#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
#include <deque>

#define FPS 60
#define CSIZE 3
#include <math.h>

#define timestep 1.0f / FPS


using namespace std;

void printInstructions() {
		cout << "\n----- CONTROLS -----" << endl;
		cout << "H for more Help" << endl;
		cout << "P for pause/resume" << endl;
		cout << "------------" << endl;
		cout << "LISTENER CONTROLS" << endl;
		cout << "W for pitch Up" << endl;
		cout << "A for pitch Left" << endl;
		cout << "S for volume Down" << endl;
		cout << "D for volume Right" << endl;
		cout << "------------" << endl;	
		cout << "SOUND CONTROLS" << endl;
		cout << "Arrow keys" << endl;
		cout << "------------" << endl;
}

int main( void ) {	
	string soundName = "";
	cout << "\nEnter sound file name: ";
	getline(cin, soundName);

    sf::RenderWindow window( sf::VideoMode( 800, 600 ), "SFML sound!" );
    int winx = window.getSize().x;
	int winy = window.getSize().y;
	window.setFramerateLimit( FPS );

	sf::CircleShape listenerCirc( 20.f );
    listenerCirc.setFillColor( sf::Color::Red );
    listenerCirc.setPosition(50,0);
    float radius = listenerCirc.getRadius();
    
    sf::Listener::setPosition(listenerCirc.getPosition().x, 0,0);
    sf::Listener::setDirection(listenerCirc.getPosition().x, 0, -1);
    sf::Listener::setGlobalVolume(2000);

    sf::CircleShape soundCirc( 20.f );
    soundCirc.setFillColor( sf::Color::Cyan );
    soundCirc.setPosition(100,0);
    float radius2 = soundCirc.getRadius();
    
    sf::SoundBuffer buffer;
	if (!buffer.loadFromFile(soundName))
		cout << "fuck you jann" << endl;
    
	sf::Vector2f distance (listenerCirc.getPosition().x - soundCirc.getPosition().x, listenerCirc.getPosition().y - soundCirc.getPosition().y);//changes depends on 2 centers
	float distanceDiag = sqrt((distance.x*distance.x) + (distance.y*distance.y));
	float attenuation = 5.0f;
	float minDistance = 80.0f;

	sf::Sound sound; 
	sound.setBuffer(buffer);
    sound.setPosition(soundCirc.getPosition().x, 0, 0);
    sound.setRelativeToListener(true);
    sound.setMinDistance(minDistance);
    sound.setAttenuation(attenuation);

    float volume = 0.f;
    volume = minDistance / (minDistance + attenuation * (max(distanceDiag, minDistance) - minDistance));
    sound.setVolume(volume);

    sound.play();

    sound.setLoop(true);

	bool moveW = false;
	bool moveA = false;
	bool moveS = false;
	bool moveD = false;

	bool moveUp = false;
	bool moveDown = false;
	bool moveRight = false;
	bool moveLeft = false;

	printInstructions();

    while( window.isOpen() ) {
        sf::Event event;
        while( window.pollEvent( event ) ) {
            switch( event.type ) {
			case sf::Event::Closed:
                window.close();
				break;
			case sf::Event::KeyPressed:
				if (event.key.code == sf::Keyboard::P) {
					if(sound.getStatus() == sf::SoundSource::Playing) 
						sound.pause();
					else if(sound.getStatus() == sf::SoundSource::Paused)
						sound.play(); 
				}
				if (event.key.code == sf::Keyboard::H)
					printInstructions();

				if (event.key.code == sf::Keyboard::W) 
					moveW = true;
				if (event.key.code == sf::Keyboard::A) 
					moveA = true;
				if (event.key.code == sf::Keyboard::S) 
					moveS = true;
				if (event.key.code == sf::Keyboard::D) 
					moveD = true;

				if (event.key.code == sf::Keyboard::Up)
					moveUp = true;
				if (event.key.code == sf::Keyboard::Down)
					moveDown = true; 
				if (event.key.code == sf::Keyboard::Left)
					moveLeft = true;
				if (event.key.code == sf::Keyboard::Right)
					moveRight = true;
				break;

			case sf::Event::KeyReleased:
				if (event.key.code == sf::Keyboard::W)
					moveW = false;
				if (event.key.code == sf::Keyboard::A)
					moveA = false;
				if (event.key.code == sf::Keyboard::S)
					moveS = false;
				if (event.key.code == sf::Keyboard::D)
					moveD = false;
				if (event.key.code == sf::Keyboard::Up)
					moveUp = false;
				if (event.key.code == sf::Keyboard::Down)
					moveDown = false;
				if (event.key.code == sf::Keyboard::Left)
					moveLeft = false;
				if (event.key.code == sf::Keyboard::Right)
					moveRight = false;
				break;
			}
        }

        if (moveW)
			listenerCirc.move(0,-100*timestep);
        if (moveA)
			listenerCirc.move(-100*timestep,0);
		if (moveS)
			listenerCirc.move(0,100*timestep);        
        if (moveD)
			listenerCirc.move(100*timestep,0);
        if (moveUp)
 			soundCirc.move(0,-100*timestep);       	
        if (moveLeft)
 			soundCirc.move(-100*timestep,0);      		
        if (moveDown)
 			soundCirc.move(0,100*timestep);       	
        if (moveRight)
 			soundCirc.move(100*timestep,0);       	

	        if(listenerCirc.getPosition().y < 0 )	        	
	        	listenerCirc.setPosition(listenerCirc.getPosition().x, 0);	      
	 		if(listenerCirc.getPosition().y + (2*radius) > winy  )	        	
	        	listenerCirc.setPosition(listenerCirc.getPosition().x, winy-2*radius);	        	
			if(listenerCirc.getPosition().x < 0 )	        	
	        	listenerCirc.setPosition(0,listenerCirc.getPosition().y);	        	
	        if(listenerCirc.getPosition().x + (2*radius) > winx)
        		listenerCirc.setPosition(winx-2*radius, listenerCirc.getPosition().y);	        	
	        if(soundCirc.getPosition().y < 0 )        	
	        	soundCirc.setPosition(soundCirc.getPosition().x, 0);	        	
	        if(soundCirc.getPosition().y + (2*radius) > winy  )       	
        		soundCirc.setPosition(soundCirc.getPosition().x, winy-2*radius2);
			if(soundCirc.getPosition().x < 0 )	        	
	        	soundCirc.setPosition(0,soundCirc.getPosition().y);	        
	        if(soundCirc.getPosition().x + (2*radius) > winx)	        
	        	soundCirc.setPosition(winx-2*radius2, soundCirc.getPosition().y);	        

	    distance.x = listenerCirc.getPosition().x - soundCirc.getPosition().x;
		distance.y = listenerCirc.getPosition().y - soundCirc.getPosition().y;

		distanceDiag = sqrt((distance.x*distance.x) + (distance.y*distance.y));

		volume = minDistance/ (minDistance + attenuation * (max(distanceDiag, minDistance) - minDistance));
		sound.setVolume(volume);

        window.clear();
        window.draw(listenerCirc);
        window.draw(soundCirc);

        window.display();
    }
    
    return 0;
}