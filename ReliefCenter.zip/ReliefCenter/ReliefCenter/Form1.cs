﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReliefCenter
{
    public partial class Form1 : Form
    {
        ReliefCenter apa;
        DataTable table = new DataTable();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Form2 makeName = new Form2();
            makeName.ShowDialog();
            rcenter.Text = makeName.CenterName;
            apa = new ReliefCenter(makeName.CenterName);
            output.Text += "Hello! Let's do some good today.\n-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-\n";

            units.Items.Add("kg");
            units.Items.Add("L");
            units.Items.Add("packs");
            units.Items.Add("cans");
            units.Items.Add("mL");
            units.Items.Add("mg");
            units.Items.Add("g");
            units.Items.Add("lbs");
            units.Items.Add("oz");
        }

        private void add_Click(object sender, EventArgs e)
        {
            if (nameGood.Text == "" || units.Text == "" || Convert.ToString(releaseRate.Text) == "")
            {
                MessageBox.Show("PLEASE FILL OUT ALL FIELDS!");
            }
            else
            {
                output.Text += apa.AddNewGood(nameGood.Text, int.Parse(releaseRate.Text), units.Text);
                nameGood.Text = null;
                releaseRate.Text = null;
                units.Text = null;
            } 
        }

        
        private void donate_Click(object sender, EventArgs e)
        {
            if (goodName.Text == "" || quantity.Text == "")
            {
                MessageBox.Show("PLEASE FILL OUT ALL FIELDS!");
            }
            else
            {
                output.Text += apa.ReceiveGoods(goodName.Text, int.Parse(quantity.Text));
                goodName.Text = null;
                quantity.Text = null;
            }
        }

        private void release_Click(object sender, EventArgs e)
        {
            if (numPacks.Text == "")
            {
                MessageBox.Show("PLEASE FILL OUT ALL FIELDS!");
            }
            else
            {
                output.Text += apa.ReleasePacks(int.Parse(numPacks.Text));
                numPacks.Text = null;
            }
        }

        private void print_Click(object sender, EventArgs e)
        {
            output.Text += apa.PrintInventory();
        }

        private void clear_Click(object sender, EventArgs e)
        {
            output.Text = null;
            output.Text += "Hello! Let's do some good today.\n-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-\n";
        }

        private void quit_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void clearAdd_Click(object sender, EventArgs e)
        {
            nameGood.Text = null;
            releaseRate.Text = null;
            units.Text = null;
        }

        private void clearDonate_Click(object sender, EventArgs e)
        { 
            goodName.Text = null;
            quantity.Text = null;
        }

        private void clearRelease_Click(object sender, EventArgs e)
        { 
            numPacks.Text = null;
        }
    }
}
