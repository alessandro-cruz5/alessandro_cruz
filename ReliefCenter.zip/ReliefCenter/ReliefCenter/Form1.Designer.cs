﻿namespace ReliefCenter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.units = new System.Windows.Forms.ComboBox();
            this.clearAdd = new System.Windows.Forms.Button();
            this.add = new System.Windows.Forms.Button();
            this.releaseRate = new System.Windows.Forms.TextBox();
            this.nameGood = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.clearDonate = new System.Windows.Forms.Button();
            this.quantity = new System.Windows.Forms.TextBox();
            this.donate = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.clearRelease = new System.Windows.Forms.Button();
            this.numPacks = new System.Windows.Forms.TextBox();
            this.release = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.output = new System.Windows.Forms.RichTextBox();
            this.print = new System.Windows.Forms.Button();
            this.clear = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.quit = new System.Windows.Forms.Button();
            this.rcenter = new System.Windows.Forms.Label();
            this.goodName = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.units);
            this.groupBox1.Controls.Add(this.clearAdd);
            this.groupBox1.Controls.Add(this.add);
            this.groupBox1.Controls.Add(this.releaseRate);
            this.groupBox1.Controls.Add(this.nameGood);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(3, 34);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(244, 133);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Add Goods";
            // 
            // units
            // 
            this.units.AutoCompleteCustomSource.AddRange(new string[] {
            "kg",
            "L",
            "packs",
            "cans",
            "oz",
            "lbs",
            "grams",
            "mL",
            "mg"});
            this.units.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.units.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.units.FormattingEnabled = true;
            this.units.Location = new System.Drawing.Point(87, 70);
            this.units.Name = "units";
            this.units.Size = new System.Drawing.Size(142, 21);
            this.units.TabIndex = 1;
            // 
            // clearAdd
            // 
            this.clearAdd.BackColor = System.Drawing.Color.SkyBlue;
            this.clearAdd.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.clearAdd.Location = new System.Drawing.Point(9, 104);
            this.clearAdd.Name = "clearAdd";
            this.clearAdd.Size = new System.Drawing.Size(94, 23);
            this.clearAdd.TabIndex = 6;
            this.clearAdd.Text = "Clear";
            this.clearAdd.UseVisualStyleBackColor = false;
            this.clearAdd.Click += new System.EventHandler(this.clearAdd_Click);
            // 
            // add
            // 
            this.add.BackColor = System.Drawing.Color.SkyBlue;
            this.add.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.add.Location = new System.Drawing.Point(134, 104);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(95, 23);
            this.add.TabIndex = 4;
            this.add.Text = "Add New Good";
            this.add.UseVisualStyleBackColor = false;
            this.add.Click += new System.EventHandler(this.add_Click);
            // 
            // releaseRate
            // 
            this.releaseRate.Location = new System.Drawing.Point(87, 48);
            this.releaseRate.Name = "releaseRate";
            this.releaseRate.Size = new System.Drawing.Size(142, 20);
            this.releaseRate.TabIndex = 4;
            // 
            // nameGood
            // 
            this.nameGood.Location = new System.Drawing.Point(87, 26);
            this.nameGood.Name = "nameGood";
            this.nameGood.Size = new System.Drawing.Size(142, 20);
            this.nameGood.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(52, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Unit:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Release Rate:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.goodName);
            this.groupBox2.Controls.Add(this.clearDonate);
            this.groupBox2.Controls.Add(this.quantity);
            this.groupBox2.Controls.Add(this.donate);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Location = new System.Drawing.Point(3, 173);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(244, 110);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Donate Goods";
            // 
            // clearDonate
            // 
            this.clearDonate.BackColor = System.Drawing.Color.SkyBlue;
            this.clearDonate.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.clearDonate.Location = new System.Drawing.Point(9, 77);
            this.clearDonate.Name = "clearDonate";
            this.clearDonate.Size = new System.Drawing.Size(94, 23);
            this.clearDonate.TabIndex = 7;
            this.clearDonate.Text = "Clear";
            this.clearDonate.UseVisualStyleBackColor = false;
            this.clearDonate.Click += new System.EventHandler(this.clearDonate_Click);
            // 
            // quantity
            // 
            this.quantity.Location = new System.Drawing.Point(87, 51);
            this.quantity.Name = "quantity";
            this.quantity.Size = new System.Drawing.Size(142, 20);
            this.quantity.TabIndex = 7;
            // 
            // donate
            // 
            this.donate.BackColor = System.Drawing.Color.SkyBlue;
            this.donate.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.donate.Location = new System.Drawing.Point(134, 81);
            this.donate.Name = "donate";
            this.donate.Size = new System.Drawing.Size(95, 23);
            this.donate.TabIndex = 6;
            this.donate.Text = "Donate Goods";
            this.donate.UseVisualStyleBackColor = false;
            this.donate.Click += new System.EventHandler(this.donate_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 29);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Relief Good:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(32, 54);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Quantity:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.clearRelease);
            this.groupBox3.Controls.Add(this.numPacks);
            this.groupBox3.Controls.Add(this.release);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Location = new System.Drawing.Point(3, 289);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(244, 88);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Release Packs";
            // 
            // clearRelease
            // 
            this.clearRelease.BackColor = System.Drawing.Color.SkyBlue;
            this.clearRelease.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.clearRelease.Location = new System.Drawing.Point(9, 59);
            this.clearRelease.Name = "clearRelease";
            this.clearRelease.Size = new System.Drawing.Size(94, 23);
            this.clearRelease.TabIndex = 8;
            this.clearRelease.Text = "Clear";
            this.clearRelease.UseVisualStyleBackColor = false;
            this.clearRelease.Click += new System.EventHandler(this.clearRelease_Click);
            // 
            // numPacks
            // 
            this.numPacks.Location = new System.Drawing.Point(87, 26);
            this.numPacks.Name = "numPacks";
            this.numPacks.Size = new System.Drawing.Size(142, 20);
            this.numPacks.TabIndex = 8;
            // 
            // release
            // 
            this.release.BackColor = System.Drawing.Color.SkyBlue;
            this.release.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.release.Location = new System.Drawing.Point(134, 59);
            this.release.Name = "release";
            this.release.Size = new System.Drawing.Size(95, 23);
            this.release.TabIndex = 7;
            this.release.Text = "Release Packs";
            this.release.UseVisualStyleBackColor = false;
            this.release.Click += new System.EventHandler(this.release_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "No. of Packs";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.output);
            this.groupBox4.Location = new System.Drawing.Point(264, 34);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(359, 430);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Output Window";
            // 
            // output
            // 
            this.output.Location = new System.Drawing.Point(6, 19);
            this.output.Name = "output";
            this.output.ReadOnly = true;
            this.output.Size = new System.Drawing.Size(345, 405);
            this.output.TabIndex = 0;
            this.output.Text = "";
            // 
            // print
            // 
            this.print.BackColor = System.Drawing.Color.SkyBlue;
            this.print.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.print.Location = new System.Drawing.Point(12, 383);
            this.print.Name = "print";
            this.print.Size = new System.Drawing.Size(229, 23);
            this.print.TabIndex = 8;
            this.print.Text = "Print Inventory";
            this.print.UseVisualStyleBackColor = false;
            this.print.Click += new System.EventHandler(this.print_Click);
            // 
            // clear
            // 
            this.clear.BackColor = System.Drawing.Color.SkyBlue;
            this.clear.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.clear.Location = new System.Drawing.Point(12, 412);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(229, 23);
            this.clear.TabIndex = 9;
            this.clear.Text = "Clear Output Window";
            this.clear.UseVisualStyleBackColor = false;
            this.clear.Click += new System.EventHandler(this.clear_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label7.Location = new System.Drawing.Point(12, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 20);
            this.label7.TabIndex = 10;
            // 
            // quit
            // 
            this.quit.BackColor = System.Drawing.Color.SkyBlue;
            this.quit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.quit.Location = new System.Drawing.Point(12, 441);
            this.quit.Name = "quit";
            this.quit.Size = new System.Drawing.Size(229, 23);
            this.quit.TabIndex = 11;
            this.quit.Text = "Quit";
            this.quit.UseVisualStyleBackColor = false;
            this.quit.Click += new System.EventHandler(this.quit_Click);
            // 
            // rcenter
            // 
            this.rcenter.AutoSize = true;
            this.rcenter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.rcenter.Location = new System.Drawing.Point(12, 9);
            this.rcenter.Name = "rcenter";
            this.rcenter.Size = new System.Drawing.Size(51, 20);
            this.rcenter.TabIndex = 12;
            this.rcenter.Text = "label8";
            // 
            // goodName
            // 
            this.goodName.Location = new System.Drawing.Point(87, 26);
            this.goodName.Name = "goodName";
            this.goodName.Size = new System.Drawing.Size(142, 20);
            this.goodName.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSalmon;
            this.ClientSize = new System.Drawing.Size(631, 470);
            this.Controls.Add(this.rcenter);
            this.Controls.Add(this.quit);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.print);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.TextBox releaseRate;
        private System.Windows.Forms.TextBox nameGood;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox quantity;
        private System.Windows.Forms.Button donate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox numPacks;
        private System.Windows.Forms.Button release;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RichTextBox output;
        private System.Windows.Forms.Button print;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button quit;
        private System.Windows.Forms.Label rcenter;
        private System.Windows.Forms.Button clearAdd;
        private System.Windows.Forms.Button clearDonate;
        private System.Windows.Forms.Button clearRelease;
        private System.Windows.Forms.ComboBox units;
        private System.Windows.Forms.TextBox goodName;
    }
}

