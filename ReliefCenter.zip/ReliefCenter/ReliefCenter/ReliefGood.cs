﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReliefCenter
{
    class ReliefGood
    {
        string goodsName;
        int releaseRate;
        string unitOfMeasurement;
        int totalUnits;

        public ReliefGood(string n, int r, string u)
        {
            goodsName = n;
            releaseRate = r;
            unitOfMeasurement = u;

        }

        public void AddGoods(int num)
        {
            totalUnits = totalUnits + num; 
        }

        public string GetName()
        {
            return goodsName;
        }

        public int GetReleaseRate()
        {
            return releaseRate;
        }

        public string GetUnit()
        {
            return unitOfMeasurement;
        }

        public int GetUnitsLeft()
        {
            return totalUnits;
        }

        public void ReleaseGoods()
        {
            totalUnits = totalUnits - releaseRate;
        }
    }
}
