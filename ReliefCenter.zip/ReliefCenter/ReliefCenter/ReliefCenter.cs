﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReliefCenter
{
    class ReliefCenter
    {
        string rcName;
        int packsReleased;
        string rGood;
        string unit;
        int releaseRate;
        int noOfGoods;
        List<ReliefGood> reliefGood;

        public ReliefCenter(string n)
        {
            rcName = n;
            packsReleased = 0;
            reliefGood = new List<ReliefGood>();
        }

        public string AddNewGood(string n, int r, string u)
        {
            rGood = n;
            releaseRate = r;
            unit = u;

            string addnew = "";
            if (FindGood(n) == null )
            {
                reliefGood.Add(new ReliefGood(n, r, u));
                addnew += rcName + " is now accepting " + n + " at the rate of " + r + " " + u + ". \n-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-\n";

            }
            else
            {
                addnew += rcName + " already contains the good " + n + ". \n-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-\n";
            }

            return addnew;
        }

        public ReliefGood FindGood(string g)
        {
            for (int i = 0; i < reliefGood.Count; i++) //finds if the given item is within the list
            {
                ReliefGood rg = reliefGood[i];
                if (g.ToLower() == rg.GetName()) //given item = name of good inputed ( or GetName())
                {
                    return rg; //if not in the list it will return rg
                }
            }
            return null; //if found in the list stops loop, returns null
        }

        public string GetName()
        {
            return rcName;
        }

        public int GetPackCount()
        {
            return packsReleased;
        }

        public string PrintInventory()
        {
            string inventory = "";
            inventory += "-=-=-=-INVENTORY-=-=-=-\n";
            inventory += "Packs Released: " + packsReleased + "\n";
            foreach (ReliefGood rGood in reliefGood)
            {
                inventory += rGood.GetName() + " " + rGood.GetUnitsLeft() + " " + rGood.GetUnit() + "\n";
            }
            inventory += "-=-=-=-=-=-=-=-=-=-=-=-=-=-\n";

            return inventory;
        }

        public string ReceiveGoods(string good, int num)
        {
            string receive = "";
            if (FindGood(good) != null)
            {
                FindGood(good).AddGoods(num);
                receive += "Received " + num + " " + FindGood(good).GetUnit() + " of " + good + ". Thank you!\n-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-\n";
            }
            else
            {
                receive += "Sorry, " + rcName + " doesn't accept " + good + " at the moment.\n-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-\n";
            }
            return receive;
        }

        public string ReleasePacks(int num)
        {
            string packs = "";
            bool enoughSupply = true;
            for (int i = 0; i < reliefGood.Count; i++) //goes through each item to see if they have enough shit
            {
                ReliefGood currentGood = reliefGood[i];
                if (currentGood.GetUnitsLeft() < currentGood.GetReleaseRate() * num)
                {
                    enoughSupply = false;
                }
            }

            if (enoughSupply == true)
            {
                for (int i = 0; i < num; i++) //gets the amount needed in an item per pack
                {
                    for (int j = 0; j < reliefGood.Count; j++) //gets the items needed to be released
                    {
                        ReliefGood relief = reliefGood[j];
                        relief.ReleaseGoods();
                    }
                }
                packs += num + " packs have been released! \n-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-\n";
                packsReleased++;
                
            }
            else
            {
                //doesnt release
                packs += "Sorry my dude, the Relief Center is lacking enough supplies to release a pack. \n-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-\n";
            }
            return packs;
        }
    }
}
