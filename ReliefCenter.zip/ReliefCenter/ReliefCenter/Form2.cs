﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReliefCenter
{
    public partial class Form2 : Form
    {
        string cName;

        public string CenterName
        {
            get { return cName; }
            set { cName = value;  }
        }

        public Form2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("PLEASE ENTER A NAME!");
            }
            else
            {
                cName = textBox1.Text;
                this.Close();
            }
        }
    }
}
